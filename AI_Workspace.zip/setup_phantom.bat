@echo off
echo ==============================================================
echo ALPHACORE PHANTOM WORKER INITIALIZATION
echo ==============================================================
echo.

:: Check for Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not in PATH for this user!
    echo Please install Python 3.10+ and check "Add Python to PATH" during installation.
    pause
    exit /b
)

:: Check/Create Virtual Environment
if not exist ".venv\Scripts\activate.bat" (
    echo [INFO] Virtual environment not found. Building .venv...
    python -m venv .venv
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b
    )
)

:: Activate Venv
call .venv\Scripts\activate.bat

:: Install Requirements
echo [INFO] Synchronizing dependencies...
pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install requirements.
    pause
    exit /b
)

:: Boot Phantom Worker
echo [INFO] Setup complete. Launching AlphaCore invisibly...
start "" wscript.exe start_phantom_worker.vbs
echo [INFO] Phantom Worker dispatched. You can close this window.
timeout /t 5 >nul
