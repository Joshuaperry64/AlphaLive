import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import json
import unittest
from unittest.mock import patch, mock_open, MagicMock

class TestLoadConfig(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Mock OS and ctypes things which might fail in headless or during import
        os.environ['QT_QPA_PLATFORM'] = 'offscreen'

        # Save original sys.modules
        cls.original_modules = sys.modules.copy()

        # Mock required modules before importing gui
        sys.modules['pyautogui'] = MagicMock()
        sys.modules['dotenv'] = MagicMock()
        sys.modules['integrations'] = MagicMock()
        sys.modules['integrations.google_workspace'] = MagicMock()
        sys.modules['memory_manager'] = MagicMock()
        sys.modules['PyQt6'] = MagicMock()
        sys.modules['PyQt6.QtWidgets'] = MagicMock()
        sys.modules['PyQt6.QtCore'] = MagicMock()
        sys.modules['PyQt6.QtGui'] = MagicMock()

        # Import gui locally to avoid polluting global scope as much as possible
        global gui
        from ui import gui

    @classmethod
    def tearDownClass(cls):
        # Restore sys.modules
        sys.modules.clear()
        sys.modules.update(cls.original_modules)

    def setUp(self):
        # We need a stable DEFAULT_CONFIG for testing
        self.original_default = gui.DEFAULT_CONFIG
        gui.DEFAULT_CONFIG = {
            "Global": {"ApiKey": "123", "Session": "test"},
            "alpha_core.py": {"AudioMode": "half"}
        }

    def tearDown(self):
        gui.DEFAULT_CONFIG = self.original_default

    @patch('pathlib.Path.exists')
    def test_load_config_not_exists(self, mock_exists):
        mock_exists.return_value = False
        config = gui.load_config()
        self.assertEqual(config, gui.DEFAULT_CONFIG)
        self.assertIsNot(config, gui.DEFAULT_CONFIG) # Should be a copy

    @patch('pathlib.Path.exists')
    @patch('builtins.open', new_callable=mock_open, read_data="invalid json")
    def test_load_config_invalid_json(self, mock_file, mock_exists):
        mock_exists.return_value = True
        config = gui.load_config()
        self.assertEqual(config, gui.DEFAULT_CONFIG)

    @patch('pathlib.Path.exists')
    def test_load_config_valid_json_with_missing_defaults(self, mock_exists):
        mock_exists.return_value = True
        saved_data = {
            "Global": {"Session": "custom_session"}
        }
        with patch('builtins.open', mock_open(read_data=json.dumps(saved_data))):
            config = gui.load_config()

        expected = {
            "Global": {"ApiKey": "123", "Session": "custom_session"},
            "alpha_core.py": {"AudioMode": "half"}
        }
        self.assertEqual(config, expected)

    @patch('pathlib.Path.exists')
    def test_load_config_empty_dict(self, mock_exists):
        mock_exists.return_value = True
        saved_data = {}
        with patch('builtins.open', mock_open(read_data=json.dumps(saved_data))):
            config = gui.load_config()
        self.assertEqual(config, gui.DEFAULT_CONFIG)

    @patch('pathlib.Path.exists')
    def test_load_config_extra_sections(self, mock_exists):
        mock_exists.return_value = True
        saved_data = {
            "Global": {"Session": "custom_session", "ExtraKey": "extra_val"},
            "ExtraSection": {"Key": "Val"}
        }
        with patch('builtins.open', mock_open(read_data=json.dumps(saved_data))):
            config = gui.load_config()

        expected = {
            "Global": {"ApiKey": "123", "Session": "custom_session", "ExtraKey": "extra_val"},
            "alpha_core.py": {"AudioMode": "half"},
            "ExtraSection": {"Key": "Val"}
        }
        self.assertEqual(config, expected)

    @patch('pathlib.Path.exists')
    def test_load_config_malformed_section_type(self, mock_exists):
        mock_exists.return_value = True
        saved_data = {
            "Global": "This is a string, not a dict"
        }
        with patch('builtins.open', mock_open(read_data=json.dumps(saved_data))):
            config = gui.load_config()

        # Due to AttributeError (or TypeError) raised when treating string as dict in load_config
        # It should fall back to DEFAULT_CONFIG
        self.assertEqual(config, gui.DEFAULT_CONFIG)

    @patch('pathlib.Path.exists')
    def test_load_config_file_read_error(self, mock_exists):
        mock_exists.return_value = True
        with patch('builtins.open', side_effect=OSError("Permission denied")):
            config = gui.load_config()
        self.assertEqual(config, gui.DEFAULT_CONFIG)

    @patch('pathlib.Path.exists')
    @patch('pathlib.Path.read_text')
    def test_get_modal_profiles_toml(self, mock_read, mock_exists):
        mock_exists.return_value = True
        mock_read.return_value = """
[alphacoreprogramming-ai]
token_id = "ak-1"

[alphacoreprogramming]
token_id = "ak-2"
active = true
"""
        profiles, active = gui.get_modal_profiles()
        self.assertIn("alphacoreprogramming-ai", profiles)
        self.assertIn("alphacoreprogramming", profiles)
        self.assertTrue(len(profiles) >= 2)

    @patch('pathlib.Path.exists')
    def test_get_modal_profiles_no_file(self, mock_exists):
        mock_exists.return_value = False
        profiles, active = gui.get_modal_profiles()
        self.assertIsInstance(profiles, list)

if __name__ == '__main__':
    unittest.main()
